public class MiniChatbot {
    public void inicio(){
        System.out.println("Olá! Eu sou o MiniChatbot. Como posso te ajudar hoje?");
    }
    public void saudacoes(){
        System.out.println("Olá! Como posso ajudar?");
    }
    public void meuNome(){
        System.out.println("Eu sou o MiniChatbot, seu assistente virtual!");
    }
    public void comoEstou(){
        System.out.println("Estou funcionando perfeitamente, obrigado!");
    }
    public void usuarioSair(){
        System.out.println("Tchau! Até a próxima.");
    }
    public void saida(){
        System.out.println("Tchau! Até a próxima.");
    }
    public void comoEstaTempo(){
        System.out.println("O tempo está com alerta de tempestade e quente!");
    }
}
